package com.example.mag

import android.location.Location

data class MapState (
    val lastKnownLocation: Location?,
//    val clusterItem: List<ZoneClusterItem>,
)