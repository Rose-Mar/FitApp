package com.example.mag.utils

